"""	Constraints for MPC.
"""

__author__ = 'Achin Jain'
__email__ = 'achinj@seas.upenn.edu'


import numpy as np
import os
import csv
import math
from track_params import TrackParams


def Boundary(x0, track_width, map, eps=0.05):
	"""	Compute linear boundary constraints given current position.
		Ain x >= bin and Aout x <= bout are both returned as A x <= b

		x			: current position [2x1]
		track 		: see bayes_race.tracks, example Rectangular etc
		eps 		: offset along center line required to compute direction

	"""
	track  = TrackParams(map)
	theta  = track.xy2theta(x0[0], x0[1])
	x_, y_ = track.theta2xy(theta+eps)
	_x, _y = track.theta2xy(theta-eps)
	x, y   = track.theta2xy(theta)
	
	_x_ = np.array([x,y])
	# if np.linalg.norm(_x_-x0,2)>1e-3:
	# 	print('WARNING: current position too far from reference...')

	norm = np.sqrt((y_-_y)**2 + (x_-_x)**2)

	width = track_width/2
	xin = x - width*(y_-_y)/norm
	yin = y + width*(x_-_x)/norm
	Ain = np.array([(y_-_y), -(x_-_x)])
	bin = (y_-_y)*xin - (x_-_x)*yin

	width = -track_width/2
	xout = x - width*(y_-_y)/norm
	yout = y + width*(x_-_x)/norm
	Aout = np.array([(y_-_y), -(x_-_x)])
	bout = (y_-_y)*xout - (x_-_x)*yout

	A = np.concatenate([[-Ain],[Aout]])
	b = np.concatenate([[-bin],[bout]]).reshape(-1,1)
	return A, b

if __name__ == '__main__':
	x0  = [-0.44708959788569586, -0.09416882273686002]
	map = "Shanghai"
	track_width = 2.6
	A, b = Boundary(x0, track_width, map)
	# print(np.dot(A,x0))
